# AminoInvite

بوت الدعوة 

## for install 

```
apt install git 
apt install python
pip install Amino.py
git clone https://github.com/kira-xc/AminoInvite
```

## for use 

```
cd AminoInvite
python invite.py
```

### not nessisary ليس ضروري 

وضع 

deviceid 


```
python deviceid.py

```

